import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { importFromCSV } from '@/lib/csvUtils'

export async function POST(req: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { csv } = body
  if (!csv) return NextResponse.json({ error: 'No CSV data provided' }, { status: 400 })

  const { accounts, liabilities, errors } = importFromCSV(csv)

  // Insert accounts
  const accountInserts = accounts.map(a => ({
    user_id: user.id,
    name: a.name,
    type: a.type,
    institution: a.institution || null,
    usd_value: a.usd_value,
    notes: a.notes || null,
    is_manual: true,
  }))

  // Insert liabilities
  const liabilityInserts = liabilities.map(l => ({
    user_id: user.id,
    name: l.name,
    type: l.type,
    institution: l.institution || null,
    usd_balance: l.usd_balance,
    notes: l.notes || null,
  }))

  const results = await Promise.allSettled([
    accountInserts.length > 0
      ? supabase.from('accounts').insert(accountInserts)
      : Promise.resolve({ data: [], error: null }),
    liabilityInserts.length > 0
      ? supabase.from('liabilities').insert(liabilityInserts)
      : Promise.resolve({ data: [], error: null }),
  ])

  return NextResponse.json({
    imported: {
      accounts: accountInserts.length,
      liabilities: liabilityInserts.length,
    },
    errors,
  })
}
